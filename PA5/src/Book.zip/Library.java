import java.util.Arrays;
import java.util.Date;
import java.util.Calendar;


public class Library {
	final public char AUTHOR_SEARCH = 'A';
	final public char OVER_DUE_SEARCH = 'O';
	final public char PATRON_SEARCH = 'P';
	final public char TITLE_SEARCH = 'T';
	private Book[] books;
	private Patron[] patrons;
	
	public Library(Book[] books, Patron[] patrons) {
		for (int i = 0; i < books.length; i++) {
			this.books[i] = books[i]; 
		}
		for (int i = 0; i < patrons.length; i++) {
			this.patrons[i] = patrons[i]; 
		}
	}
	
	public boolean checkin(Book book) {
		boolean result = false;
		if(Arrays.asList(books).contains(book) && book.getStatus() == 2) {	
			result = true;
			book.checkin();
		}
			
		
		return result;
	}
	
	public boolean checkout(Book book, Patron patron) {
		boolean result = true;
		if(!Arrays.asList(books).contains(book))	
			result = false;
				book.checkout(patron, book.getDue());
				Date date = new Date();
		
		return result;
		
	}
	
	public double determineFine(Book book) {
		Date date = new Date();
		double fine = (book.getDue() - date) * 0.5;
        return fine;
	}
	
	public Book[] searchBooks(Object key, char type) {
		return new Book[] {};
	}
	
}
