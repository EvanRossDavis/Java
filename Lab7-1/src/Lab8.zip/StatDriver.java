import java.util.Scanner;
import java.util.ArrayList;

/**
 * This program reads some numbers from the terminal and calculates their mean
 * and standard deviation.
 * 
 * @author Farzana Rahman
 * @version 10/17/2016
 *
 */
public class StatDriver {

   /**
    * Reads numbers and prints their mean and standard deviation to the
    * terminal.
    * 
    * @param args - args[0] should contain the number of values that will be
    *           read, 15 is the default if no command line argument is provided
    */
   @SuppressWarnings("resource")
public static void main(String[] args) {

      Scanner input;
      ArrayList<Double> data;
      int dataSize;
      String userInput = "";

      // Determine the appropriate array size.
      if (args.length > 0) {
         dataSize = Integer.parseInt(args[0]);
      } else {
         dataSize = 15;
      }

      // Create the array.
      data = new ArrayList<Double>(dataSize);

      // Read values from the terminal.
      input = new Scanner(System.in);
      while (input.hasNextDouble()) {
         data.add(input.nextDouble());
      }

      // Calculate and display the results.
      if(args[0] == "mean") {
    	  System.out.printf("Mean: %.2f\n", Stats.mean(data));
      }
      else if (args[0] == "std") {
    	  System.out.printf("StdDev: %.2f\n", Stats.stdDev(data));
      }
      else {
    	  System.out.printf("Mean: %.2f\n", Stats.mean(data));
      }
   }

}
