/**
 * Title:		Assignment 4
 * Semester:	COP3337 - Fall 2018
 * @author 		Evan Ross Davis
 * 
 *  I affirm that this program is entirely my own work
 *  and none of it is the work of any other person.
 **/

public interface NumberFormatter {
	
	//Method declaration.
	public String format(int n);
}
